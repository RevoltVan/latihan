class Company {
  final int id;
  final String name;

  Company({required this.id, required this.name});
}
