class Snack {
  final int id;
  final String name;
  final int stock;
  final String description;
  final int companyId;

  Snack({
    required this.id,
    required this.name,
    required this.stock,
    required this.description,
    required this.companyId,
  });
}
