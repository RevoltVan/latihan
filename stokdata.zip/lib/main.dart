import 'package:flutter/material.dart';
import 'pages/company_list_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Stock Management',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CompanyListPage(), // Mengarahkan ke halaman daftar perusahaan
    );
  }
}
