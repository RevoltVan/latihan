import 'package:flutter/material.dart';
import '../models/company.dart';
import '../services/api_service.dart';
import 'snack_list_page.dart';

class CompanyListPage extends StatefulWidget {
  @override
  _CompanyListPageState createState() => _CompanyListPageState();
}

class _CompanyListPageState extends State<CompanyListPage> {
  final ApiService apiService = ApiService();
  late Future<List<Company>> futureCompanies;

  @override
  void initState() {
    super.initState();
    futureCompanies = apiService.fetchCompanies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Daftar Perusahaan')),
      body: FutureBuilder<List<Company>>(
        future: futureCompanies,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Tidak ada perusahaan'));
          }

          final companies = snapshot.data!;
          return ListView.builder(
            itemCount: companies.length,
            itemBuilder: (context, index) {
              final company = companies[index];
              return ListTile(
                title: Text(company.name),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          SnackListPage(companyId: company.id),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
