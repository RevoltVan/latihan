import 'package:flutter/material.dart';
import '../models/snack.dart';
import '../services/api_service.dart';

class SnackListPage extends StatefulWidget {
  final int companyId;

  SnackListPage({required this.companyId});

  @override
  _SnackListPageState createState() => _SnackListPageState();
}

class _SnackListPageState extends State<SnackListPage> {
  final ApiService apiService = ApiService();
  late Future<List<Snack>> futureSnacks;

  @override
  void initState() {
    super.initState();
    futureSnacks = apiService.fetchSnacks(widget.companyId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Stok Snack')),
      body: FutureBuilder<List<Snack>>(
        future: futureSnacks,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Tidak ada snack'));
          }

          final snacks = snapshot.data!;
          return ListView.builder(
            itemCount: snacks.length,
            itemBuilder: (context, index) {
              final snack = snacks[index];
              return ListTile(
                title: Text(snack.name),
                subtitle: Text('Stok: ${snack.stock} - ${snack.description}'),
              );
            },
          );
        },
      ),
    );
  }
}
