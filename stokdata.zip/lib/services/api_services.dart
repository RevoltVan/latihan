import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/company.dart';
import '../models/snack.dart';

class ApiService {
  final String baseUrl = 'http://your-api-url.com'; // Ganti dengan URL API Anda

  Future<List<Company>> fetchCompanies() async {
    final response = await http.get(Uri.parse('$baseUrl/companies'));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse
          .map((company) => Company(id: company['id'], name: company['name']))
          .toList();
    } else {
      throw Exception('Failed to load companies');
    }
  }

  Future<List<Snack>> fetchSnacks(int companyId) async {
    final response =
        await http.get(Uri.parse('$baseUrl/snacks?company_id=$companyId'));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse
          .map((snack) => Snack(
                id: snack['id'],
                name: snack['name'],
                stock: snack['stock'],
                description: snack['description'],
                companyId: snack['company_id'],
              ))
          .toList();
    } else {
      throw Exception('Failed to load snacks');
    }
  }

  Future<void> addSnack(Snack snack) async {
    await http.post(
      Uri.parse('$baseUrl/snacks'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'name': snack.name,
        'stock': snack.stock,
        'description': snack.description,
        'company_id': snack.companyId,
      }),
    );
  }

  // Tambahkan fungsi lain untuk edit dan delete snack sesuai kebutuhan
}
